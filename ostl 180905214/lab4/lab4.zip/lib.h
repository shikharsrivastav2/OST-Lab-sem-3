void bill(char *);
void fred(int);
