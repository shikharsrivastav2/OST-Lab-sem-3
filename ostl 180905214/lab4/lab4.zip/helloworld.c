#include<stdlib.h>
#include "lib.h"
int main()
{
	bill("hello world");
	exit(0);
	
}