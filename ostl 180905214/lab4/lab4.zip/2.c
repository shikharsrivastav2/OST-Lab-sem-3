#include "a.h"
#include "b.h"
void function_two(){
	
}