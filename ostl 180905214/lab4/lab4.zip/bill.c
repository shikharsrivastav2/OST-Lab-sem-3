#include<stdio.h>
void bill(char *arg)
{
	printf("bill: we passed %s\n",arg);
	
}