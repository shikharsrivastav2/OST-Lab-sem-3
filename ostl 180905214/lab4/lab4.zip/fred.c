#include<stdio.h>
void fred(int arg)
{
	printf("fred:we passed %d\n",arg);

}
